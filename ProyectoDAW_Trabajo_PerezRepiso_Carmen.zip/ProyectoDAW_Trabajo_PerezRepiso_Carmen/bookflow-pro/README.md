# 📚 BookFlow Pro — Sistema de Gestión de Bibliotecas

> **Proyecto Intermodular — Técnico Superior en Desarrollo de Aplicaciones Web (DAW)**

---

## Índice

1. [Descripción del proyecto](#descripción-del-proyecto)
2. [Módulos del ciclo cubiertos](#módulos-del-ciclo-cubiertos)
3. [Tecnologías utilizadas](#tecnologías-utilizadas)
4. [Arquitectura del sistema](#arquitectura-del-sistema)
5. [Estructura de carpetas](#estructura-de-carpetas)
6. [Base de datos](#base-de-datos)
7. [API REST — Endpoints](#api-rest--endpoints)
8. [Instalación y puesta en marcha](#instalación-y-puesta-en-marcha)
9. [Credenciales de prueba](#credenciales-de-prueba)
10. [Funcionalidades implementadas](#funcionalidades-implementadas)

---

## Descripción del proyecto

**BookFlow Pro** es una aplicación web completa para la gestión de bibliotecas. Permite administrar el catálogo de libros, registrar préstamos y devoluciones, y gestionar los usuarios del sistema.

La aplicación sigue una arquitectura **cliente-servidor** con una API REST en el backend y una SPA (Single Page Application) ligera en el frontend.

---

## Módulos del ciclo cubiertos

| Módulo | Cómo se aplica en el proyecto |
|---|---|
| **Lenguajes de marcas y sistemas de gestión de información** | HTML5 semántico con etiquetas `<main>`, `<nav>`, `<section>`, `<footer>`, atributos ARIA, `<meta>` descriptivos |
| **Bases de Datos** | MySQL con esquema relacional, claves foráneas, índices, transacciones, JOINs, restricciones CHECK |
| **Programación** | JavaScript ES6+: módulos, async/await, arrow functions, destructuring, template literals, manejo de errores |
| **Entornos de desarrollo** | Node.js, npm, nodemon, variables de entorno con dotenv, `.env.example` |
| **Sistemas informáticos** | Arquitectura cliente-servidor, protocolo HTTP/REST, sistema de archivos, variables de entorno del SO |
| **Desarrollo web en entorno cliente** | Fetch API, manipulación del DOM, eventos, validación de formularios, localStorage, Bootstrap 5 |
| **Desarrollo web en entorno servidor** | Express.js, middleware JWT, bcrypt, arquitectura MVC, manejo de errores global, transacciones SQL |
| **Despliegue de aplicaciones web** | Instrucciones de instalación, `.env.example`, scripts npm (`start`, `dev`), separación frontend/backend |
| **Diseño de interfaces web** | Bootstrap 5, CSS custom properties, diseño responsive, accesibilidad WCAG (skip links, ARIA, contraste) |
| **Proyecto Intermodular DAW** | Integración de todos los módulos en una aplicación funcional completa |

---

## Tecnologías utilizadas

### Backend
- **Node.js** — Entorno de ejecución JavaScript en servidor
- **Express.js** — Framework web para la API REST
- **MySQL2** — Driver para base de datos MySQL con soporte de Promises
- **bcryptjs** — Hash seguro de contraseñas
- **jsonwebtoken (JWT)** — Autenticación stateless mediante tokens
- **dotenv** — Gestión de variables de entorno
- **cors** — Control de acceso entre orígenes

### Frontend
- **HTML5** — Lenguaje de marcas con semántica y accesibilidad
- **CSS3** — Estilos con custom properties y diseño responsive
- **Bootstrap 5** — Framework CSS/JS para interfaz de usuario
- **JavaScript (ES6+)** — Lógica del cliente con Fetch API

### Base de datos
- **MySQL** — Sistema gestor de bases de datos relacional

---

## Arquitectura del sistema

```
┌─────────────────────────────────────────────────────────┐
│                     CLIENTE (Browser)                    │
│  HTML5 + CSS3 + Bootstrap 5 + JavaScript (Fetch API)    │
└──────────────────────┬──────────────────────────────────┘
                       │ HTTP/REST (JSON)
                       │ Authorization: Bearer <JWT>
┌──────────────────────▼──────────────────────────────────┐
│                  SERVIDOR (Node.js + Express)            │
│                                                          │
│  ┌─────────┐   ┌────────────┐   ┌──────────────────┐   │
│  │ Routes  │──▶│ Middleware │──▶│   Controllers    │   │
│  │         │   │ JWT / Val. │   │ libros/prestamos │   │
│  └─────────┘   └────────────┘   │    /usuarios     │   │
│                                  └────────┬─────────┘   │
└───────────────────────────────────────────┼─────────────┘
                                            │ SQL
┌───────────────────────────────────────────▼─────────────┐
│                    BASE DE DATOS (MySQL)                  │
│              usuarios | libros | prestamos               │
└─────────────────────────────────────────────────────────┘
```

---

## Estructura de carpetas

```
bookflow-pro/
├── Backend/
│   ├── config/
│   │   ├── db.js
│   │   └── env.js
│   ├── controllers/
│   │   ├── libroController.js
│   │   ├── prestamoController.js
│   │   └── usuarioController.js
│   ├── database/
│   │   └── bookflow.sql
│   ├── middleware/
│   │   ├── auth.js
│   │   └── validate.js
│   ├── models/
│   ├── routes/
│   │   ├── libros.js
│   │   ├── prestamos.js
│   │   └── usuarios.js
│   ├── .env
│   ├── .env.example
│   ├── package.json
│   └── server.js
│
└── frontend/
├── assets/
│   ├── Portadas/           # Imágenes de portadas de libros
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── auth.js
│       ├── libros.js
│       ├── main.js
│       ├── prestamos.js
│       └── usuarios.js
├── dashboard.html
├── index.html
├── libros.html
├── login.html
├── prestamos.html
└── usuarios.html
```

---

## Base de datos

### Diagrama entidad-relación

```
usuarios (1) ──────< prestamos >────── (1) libros
   id PK                id PK               id PK
   nombre               usuario_id FK       titulo
   email UNIQUE         libro_id FK         autor
   password             fecha_prestamo      isbn UNIQUE
   rol ENUM             fecha_dev_esperada  editorial
   activo               fecha_dev_real      ano_publicacion
   fecha_registro       estado ENUM         categoria
                        notas               descripcion
                                            cantidad_total
                                            cantidad_disponible
```

### Crear la base de datos

```sql
-- Ejecutar en MySQL Workbench o desde terminal:
mysql -u root -p < Backend/database/bookflow.sql
```

---

## API REST — Endpoints

Todas las rutas (excepto login y registro) requieren el header:
```
Authorization: Bearer <token>
```

### Usuarios
| Método | Ruta | Acceso | Descripción |
|--------|------|--------|-------------|
| POST | `/api/usuarios/login` | Público | Iniciar sesión |
| POST | `/api/usuarios/registro` | Público | Crear cuenta |
| GET | `/api/usuarios` | Admin | Listar usuarios |
| PUT | `/api/usuarios/:id/rol` | Admin | Cambiar rol |
| DELETE | `/api/usuarios/:id` | Admin | Desactivar usuario |

### Libros
| Método | Ruta | Acceso | Descripción |
|--------|------|--------|-------------|
| GET | `/api/libros` | Auth | Listar libros (con filtros) |
| GET | `/api/libros/categorias` | Auth | Listar categorías |
| GET | `/api/libros/:id` | Auth | Obtener un libro |
| POST | `/api/libros` | Admin | Crear libro |
| PUT | `/api/libros/:id` | Admin | Actualizar libro |
| DELETE | `/api/libros/:id` | Admin | Eliminar libro |

### Préstamos
| Método | Ruta | Acceso | Descripción |
|--------|------|--------|-------------|
| GET | `/api/prestamos` | Admin | Listar préstamos |
| GET | `/api/prestamos/estadisticas` | Admin | Estadísticas del dashboard |
| POST | `/api/prestamos` | Admin | Crear préstamo |
| PUT | `/api/prestamos/:id/devolver` | Admin | Registrar devolución |

---

## Instalación y puesta en marcha

### Requisitos previos
- Node.js v18 o superior
- MySQL 8.0 o superior
- npm

### 1. Clonar el repositorio

```bash
git clone <url-del-repositorio>
cd bookflow-pro
```

### 2. Configurar la base de datos

```bash
# Acceder a MySQL y ejecutar el script
mysql -u root -p < Backend/database/bookflow.sql
```

### 3. Configurar variables de entorno

```bash
cd Backend
copy .env.example .env
# Editar .env con tus credenciales de MySQL
```

### 4. Instalar dependencias e iniciar el servidor

```bash
cd Backend
npm install
npm run dev        # Modo desarrollo (nodemon)
# o
npm start          # Modo producción
```

El servidor arrancará en `http://localhost:5000`

### 5. Abrir el frontend

Abrir `frontend/login.html` directamente en el navegador, o usar una extensión como **Live Server** en VS Code.

---

## Credenciales de prueba

| Usuario | Email | Contraseña | Rol |
|---------|-------|------------|-----|
| Administrador | admin@bookflow.com | admin123 | admin |
| María García | maria@bookflow.com | admin123 | usuario |
| Carlos López | carlos@bookflow.com | admin123 | usuario |

---

## Funcionalidades implementadas

- ✅ Autenticación con JWT (login / registro / logout)
- ✅ Control de roles: admin y usuario
- ✅ Middleware de autenticación en todas las rutas protegidas
- ✅ CRUD completo de libros con búsqueda y filtros
- ✅ Control de stock automático al prestar/devolver
- ✅ Transacciones SQL para garantizar integridad de datos
- ✅ Gestión de préstamos con estados (activo / devuelto / vencido)
- ✅ Dashboard con estadísticas en tiempo real
- ✅ Gestión de usuarios (cambio de rol, desactivación)
- ✅ Diseño responsive con Bootstrap 5
- ✅ Accesibilidad: skip links, atributos ARIA, semántica HTML5
- ✅ Prevención de XSS mediante escape de HTML en el cliente
- ✅ Notificaciones toast en lugar de alert()
- ✅ Manejo global de errores en el servidor
- ✅ Validación de entradas en backend y frontend

---

*Desarrollado como Proyecto Intermodular del ciclo Técnico Superior en Desarrollo de Aplicaciones Web (DAW)*
