const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const env = require('./config/env');

const app = express();
const PORT = env.PORT;

// =======================
// Middlewares de Seguridad
// =======================
app.use(helmet());

app.use(cors({
  origin: env.NODE_ENV === 'production' ? false : '*', // Cambia a tu dominio en producción
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Rate Limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 120,
  message: { error: 'Demasiadas solicitudes. Por favor, inténtalo más tarde.' }
});

app.use('/api/', limiter);
app.use(express.json({ limit: '10mb' }));

// =======================
// Rutas
// =======================
app.use('/api/libros',    require('./routes/libros'));
app.use('/api/usuarios',  require('./routes/usuarios'));
app.use('/api/prestamos', require('./routes/prestamos'));

app.get('/api', (req, res) => {
  res.json({
    mensaje: '✅ BookFlow Pro API v1.1.0 - Mejorada',
    status: 'ok',
    environment: env.NODE_ENV,
    version: '1.1.0'
  });
});

// Servir frontend (producción)
if (env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../frontend')));
}

// Error handler global
app.use((err, req, res, next) => {
  console.error('[ERROR]', err);
  res.status(500).json({
    error: 'Error interno del servidor',
    mensaje: env.NODE_ENV === 'development' ? err.message : 'Contacta con el administrador'
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Servidor BookFlow Pro corriendo en http://localhost:${PORT}`);
  console.log(`🌍 Entorno: ${env.NODE_ENV}`);
});
