const pool = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ mensaje: 'Email y contraseña son obligatorios.' });
    }

    const [usuarios] = await pool.query(
      'SELECT * FROM usuarios WHERE email = ? AND activo = 1',
      [email.toLowerCase().trim()],
    );

    if (usuarios.length === 0) {
      return res.status(401).json({ mensaje: 'Credenciales incorrectas.' });
    }

    const usuario = usuarios[0];
    const validPassword = await bcrypt.compare(password, usuario.password);

    if (!validPassword) {
      return res.status(401).json({ mensaje: 'Credenciales incorrectas.' });
    }

    const token = jwt.sign(
      { id: usuario.id, rol: usuario.rol, nombre: usuario.nombre },
      process.env.JWT_SECRET || 'bookflow_pro_secret_2026',
      { expiresIn: '8h' },
    );

    res.json({
      token,
      usuario: {
        id: usuario.id,
        nombre: usuario.nombre,
        email: usuario.email,
        rol: usuario.rol,
      },
    });
  } catch (error) {
    console.error('[usuarioController.login]', error);
    res.status(500).json({ mensaje: 'Error del servidor.' });
  }
};

exports.registro = async (req, res) => {
  try {
    const { nombre, email, password } = req.body;

    if (!nombre || !email || !password) {
      return res.status(400).json({ mensaje: 'Todos los campos son obligatorios.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ mensaje: 'La contraseña debe tener al menos 6 caracteres.' });
    }

    const emailNorm = email.toLowerCase().trim();
    const [existente] = await pool.query('SELECT id FROM usuarios WHERE email = ?', [emailNorm]);
    if (existente.length > 0) {
      return res.status(409).json({ mensaje: 'Este correo ya está registrado.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const [result] = await pool.query(
      'INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)',
      [nombre.trim(), emailNorm, hashedPassword],
    );

    res.status(201).json({ id: result.insertId, mensaje: 'Usuario registrado correctamente.' });
  } catch (error) {
    console.error('[usuarioController.registro]', error);
    res.status(500).json({ mensaje: 'Error al registrar el usuario.' });
  }
};

exports.getUsuarios = async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, nombre, email, rol, activo, fecha_registro FROM usuarios ORDER BY nombre',
    );
    res.json(rows);
  } catch (error) {
    console.error('[usuarioController.getUsuarios]', error);
    res.status(500).json({ error: 'Error al obtener los usuarios.' });
  }
};

exports.cambiarRol = async (req, res) => {
  try {
    const { rol } = req.body;
    if (!['admin', 'usuario'].includes(rol)) {
      return res.status(400).json({ mensaje: "El rol debe ser 'admin' o 'usuario'." });
    }

    const [result] = await pool.query(
      'UPDATE usuarios SET rol = ? WHERE id = ?',
      [rol, req.params.id],
    );
    if (result.affectedRows === 0) return res.status(404).json({ mensaje: 'Usuario no encontrado.' });
    res.json({ mensaje: 'Rol actualizado correctamente.' });
  } catch (error) {
    console.error('[usuarioController.cambiarRol]', error);
    res.status(500).json({ error: 'Error al cambiar el rol.' });
  }
};

exports.desactivarUsuario = async (req, res) => {
  try {
    if (parseInt(req.params.id, 10) === req.usuario.id) {
      return res.status(400).json({ mensaje: 'No puedes desactivar tu propia cuenta.' });
    }

    const [result] = await pool.query(
      'UPDATE usuarios SET activo = 0 WHERE id = ?',
      [req.params.id],
    );
    if (result.affectedRows === 0) return res.status(404).json({ mensaje: 'Usuario no encontrado.' });
    res.json({ mensaje: 'Usuario desactivado correctamente.' });
  } catch (error) {
    console.error('[usuarioController.desactivarUsuario]', error);
    res.status(500).json({ error: 'Error al desactivar el usuario.' });
  }
};
