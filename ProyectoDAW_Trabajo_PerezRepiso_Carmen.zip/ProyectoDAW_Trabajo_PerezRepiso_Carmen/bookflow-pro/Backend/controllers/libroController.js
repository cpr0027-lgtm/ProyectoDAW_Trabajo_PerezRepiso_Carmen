const pool = require('../config/db');

exports.getAllLibros = async (req, res) => {
  try {
    const { buscar, categoria } = req.query;
    let sql = 'SELECT * FROM libros';
    const params = [];

    const conditions = [];
    if (buscar) {
      conditions.push('(titulo LIKE ? OR autor LIKE ?)');
      params.push(`%${buscar}%`, `%${buscar}%`);
    }
    if (categoria) {
      conditions.push('categoria = ?');
      params.push(categoria);
    }
    if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ');
    sql += ' ORDER BY titulo';

    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (error) {
    console.error('[libroController.getAllLibros]', error);
    res.status(500).json({ error: 'Error al obtener los libros.' });
  }
};

exports.getLibroById = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM libros WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ mensaje: 'Libro no encontrado.' });
    res.json(rows[0]);
  } catch (error) {
    console.error('[libroController.getLibroById]', error);
    res.status(500).json({ error: 'Error al obtener el libro.' });
  }
};

exports.crearLibro = async (req, res) => {
  try {
    const {
      titulo, autor, isbn, editorial,
      ano_publicacion, cantidad_total, categoria, descripcion,
    } = req.body;

    const cantidad = parseInt(cantidad_total, 10) || 1;

    const [result] = await pool.query(
      `INSERT INTO libros
         (titulo, autor, isbn, editorial, ano_publicacion,
          cantidad_total, cantidad_disponible, categoria, descripcion)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [titulo, autor, isbn || null, editorial || null,
       ano_publicacion || null, cantidad, cantidad, categoria || null, descripcion || null],
    );

    res.status(201).json({ id: result.insertId, mensaje: 'Libro creado correctamente.' });
  } catch (error) {
    console.error('[libroController.crearLibro]', error);
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Ya existe un libro con ese ISBN.' });
    }
    res.status(500).json({ error: 'Error al crear el libro.' });
  }
};

exports.actualizarLibro = async (req, res) => {
  try {
    const {
      titulo, autor, isbn, editorial,
      ano_publicacion, cantidad_total, categoria, descripcion,
    } = req.body;

    const [result] = await pool.query(
      `UPDATE libros SET
         titulo = ?, autor = ?, isbn = ?, editorial = ?,
         ano_publicacion = ?, cantidad_total = ?, categoria = ?, descripcion = ?
       WHERE id = ?`,
      [titulo, autor, isbn || null, editorial || null,
       ano_publicacion || null, parseInt(cantidad_total, 10) || 1,
       categoria || null, descripcion || null, req.params.id],
    );

    if (result.affectedRows === 0) return res.status(404).json({ mensaje: 'Libro no encontrado.' });
    res.json({ mensaje: 'Libro actualizado correctamente.' });
  } catch (error) {
    console.error('[libroController.actualizarLibro]', error);
    res.status(500).json({ error: 'Error al actualizar el libro.' });
  }
};

exports.eliminarLibro = async (req, res) => {
  try {
    const [activos] = await pool.query(
      "SELECT id FROM prestamos WHERE libro_id = ? AND estado = 'activo'",
      [req.params.id],
    );
    if (activos.length > 0) {
      return res.status(409).json({ error: 'No se puede eliminar: el libro tiene préstamos activos.' });
    }

    const [result] = await pool.query('DELETE FROM libros WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ mensaje: 'Libro no encontrado.' });
    res.json({ mensaje: 'Libro eliminado correctamente.' });
  } catch (error) {
    console.error('[libroController.eliminarLibro]', error);
    res.status(500).json({ error: 'Error al eliminar el libro.' });
  }
};

exports.getCategorias = async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT DISTINCT categoria FROM libros WHERE categoria IS NOT NULL ORDER BY categoria',
    );
    res.json(rows.map((r) => r.categoria));
  } catch (error) {
    console.error('[libroController.getCategorias]', error);
    res.status(500).json({ error: 'Error al obtener categorías.' });
  }
};
