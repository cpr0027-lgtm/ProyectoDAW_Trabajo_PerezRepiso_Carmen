const pool = require('../config/db');

exports.getMisPrestamos = async (req, res) => {
  try {
    const { estado } = req.query;
    let sql = `
      SELECT
        p.id,
        p.fecha_prestamo,
        p.fecha_devolucion_esperada,
        p.fecha_devolucion_real,
        p.estado,
        p.notas,
        l.id    AS libro_id,
        l.titulo AS libro_titulo,
        l.autor  AS libro_autor
      FROM prestamos p
      JOIN libros l ON p.libro_id = l.id
      WHERE p.usuario_id = ?
    `;
    const params = [req.usuario.id];
    if (estado) {
      sql += ' AND p.estado = ?';
      params.push(estado);
    }
    sql += ' ORDER BY p.fecha_prestamo DESC';

    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (error) {
    console.error('[prestamoController.getMisPrestamos]', error);
    res.status(500).json({ error: 'Error al obtener tus préstamos.' });
  }
};

exports.getPrestamos = async (req, res) => {
  try {
    const { estado } = req.query;
    let sql = `
      SELECT
        p.id,
        p.fecha_prestamo,
        p.fecha_devolucion_esperada,
        p.fecha_devolucion_real,
        p.estado,
        p.notas,
        u.id   AS usuario_id,
        u.nombre AS usuario_nombre,
        u.email  AS usuario_email,
        l.id   AS libro_id,
        l.titulo AS libro_titulo,
        l.autor  AS libro_autor
      FROM prestamos p
      JOIN usuarios u ON p.usuario_id = u.id
      JOIN libros   l ON p.libro_id   = l.id
    `;
    const params = [];
    if (estado) {
      sql += ' WHERE p.estado = ?';
      params.push(estado);
    }
    sql += ' ORDER BY p.fecha_prestamo DESC';

    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (error) {
    console.error('[prestamoController.getPrestamos]', error);
    res.status(500).json({ error: 'Error al obtener los préstamos.' });
  }
};

exports.crearPrestamo = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const { usuario_id, libro_id, fecha_devolucion_esperada, notas } = req.body;

    const [[libro]] = await conn.query(
      'SELECT cantidad_disponible FROM libros WHERE id = ? FOR UPDATE',
      [libro_id],
    );
    if (!libro) {
      await conn.rollback();
      return res.status(404).json({ error: 'Libro no encontrado.' });
    }
    if (libro.cantidad_disponible <= 0) {
      await conn.rollback();
      return res.status(409).json({ error: 'No hay ejemplares disponibles de este libro.' });
    }

    const [[usuario]] = await conn.query('SELECT id FROM usuarios WHERE id = ?', [usuario_id]);
    if (!usuario) {
      await conn.rollback();
      return res.status(404).json({ error: 'Usuario no encontrado.' });
    }

    const fechaDevolucion = fecha_devolucion_esperada
      || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const [result] = await conn.query(
      'INSERT INTO prestamos (usuario_id, libro_id, fecha_devolucion_esperada, notas) VALUES (?, ?, ?, ?)',
      [usuario_id, libro_id, fechaDevolucion, notas || null],
    );

    await conn.query(
      'UPDATE libros SET cantidad_disponible = cantidad_disponible - 1 WHERE id = ?',
      [libro_id],
    );

    await conn.commit();
    res.status(201).json({ id: result.insertId, mensaje: 'Préstamo registrado correctamente.' });
  } catch (error) {
    await conn.rollback();
    console.error('[prestamoController.crearPrestamo]', error);
    res.status(500).json({ error: 'Error al crear el préstamo.' });
  } finally {
    conn.release();
  }
};

exports.devolverLibro = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const { id } = req.params;

    const [[prestamo]] = await conn.query(
      "SELECT * FROM prestamos WHERE id = ? AND estado = 'activo'",
      [id],
    );
    if (!prestamo) {
      await conn.rollback();
      return res.status(404).json({ error: 'Préstamo activo no encontrado.' });
    }

    await conn.query(
      "UPDATE prestamos SET fecha_devolucion_real = NOW(), estado = 'devuelto' WHERE id = ?",
      [id],
    );

    await conn.query(
      'UPDATE libros SET cantidad_disponible = cantidad_disponible + 1 WHERE id = ?',
      [prestamo.libro_id],
    );

    await conn.commit();
    res.json({ mensaje: 'Libro devuelto correctamente.' });
  } catch (error) {
    await conn.rollback();
    console.error('[prestamoController.devolverLibro]', error);
    res.status(500).json({ error: 'Error al registrar la devolución.' });
  } finally {
    conn.release();
  }
};

exports.getEstadisticas = async (req, res) => {
  try {
    const [[totales]] = await pool.query(`
      SELECT
        COUNT(*)                                          AS total_prestamos,
        SUM(estado = 'activo')                            AS activos,
        SUM(estado = 'devuelto')                          AS devueltos,
        SUM(estado = 'vencido')                           AS vencidos,
        SUM(estado = 'activo' AND fecha_devolucion_esperada < CURDATE()) AS en_retraso
      FROM prestamos
    `);

    const [[libros]] = await pool.query(`
      SELECT
        COUNT(*)                                 AS total_libros,
        SUM(cantidad_disponible)                 AS disponibles,
        SUM(cantidad_total - cantidad_disponible) AS prestados
      FROM libros
    `);

    const [[usuarios]] = await pool.query('SELECT COUNT(*) AS total_usuarios FROM usuarios WHERE activo = 1');

    res.json({ prestamos: totales, libros, usuarios });
  } catch (error) {
    console.error('[prestamoController.getEstadisticas]', error);
    res.status(500).json({ error: 'Error al obtener estadísticas.' });
  }
};
