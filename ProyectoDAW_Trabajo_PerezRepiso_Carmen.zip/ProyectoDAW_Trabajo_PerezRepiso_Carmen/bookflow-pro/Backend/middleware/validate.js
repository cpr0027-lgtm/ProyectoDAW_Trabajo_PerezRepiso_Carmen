const requireFields = (fields) => (req, res, next) => {
  const missing = fields.filter(field => {
    const value = req.body[field];
    return value === undefined || value === null || String(value).trim() === '';
  });

  if (missing.length > 0) {
    return res.status(400).json({
      mensaje: `Faltan campos obligatorios: ${missing.join(', ')}`
    });
  }
  next();
};

const validId = (param = 'id') => (req, res, next) => {
  const value = parseInt(req.params[param], 10);
  if (isNaN(value) || value <= 0) {
    return res.status(400).json({ mensaje: `El parámetro '${param}' debe ser un número positivo.` });
  }
  req.params[param] = value;
  next();
};

module.exports = { requireFields, validId };
