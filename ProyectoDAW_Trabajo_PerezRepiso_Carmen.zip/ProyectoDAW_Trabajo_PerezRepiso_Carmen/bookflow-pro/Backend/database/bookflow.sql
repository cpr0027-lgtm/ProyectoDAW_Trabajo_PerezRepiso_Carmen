CREATE DATABASE IF NOT EXISTS bookflow
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE bookflow;

CREATE TABLE IF NOT EXISTS usuarios (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  nombre          VARCHAR(100)        NOT NULL,
  email           VARCHAR(150)        NOT NULL UNIQUE,
  password        VARCHAR(255)        NOT NULL,
  rol             ENUM('admin','usuario') NOT NULL DEFAULT 'usuario',
  activo          TINYINT(1)          NOT NULL DEFAULT 1,
  fecha_registro  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_rol   (rol)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS libros (
  id                   INT AUTO_INCREMENT PRIMARY KEY,
  titulo               VARCHAR(200)  NOT NULL,
  autor                VARCHAR(150)  NOT NULL,
  isbn                 VARCHAR(20)   UNIQUE,
  editorial            VARCHAR(100),
  ano_publicacion      YEAR,
  categoria            VARCHAR(80),
  descripcion          TEXT,
  portada_url          VARCHAR(500),
  cantidad_total       INT           NOT NULL DEFAULT 1,
  cantidad_disponible  INT           NOT NULL DEFAULT 1,
  fecha_alta           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_titulo     (titulo),
  INDEX idx_autor      (autor),
  INDEX idx_categoria  (categoria),
  CONSTRAINT chk_cantidad CHECK (cantidad_disponible >= 0 AND cantidad_disponible <= cantidad_total)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS prestamos (
  id                        INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id                INT          NOT NULL,
  libro_id                  INT          NOT NULL,
  fecha_prestamo            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_devolucion_esperada DATE         NOT NULL,
  fecha_devolucion_real     DATETIME,
  estado                    ENUM('activo','devuelto','vencido') NOT NULL DEFAULT 'activo',
  notas                     TEXT,
  INDEX idx_usuario         (usuario_id),
  INDEX idx_libro           (libro_id),
  INDEX idx_estado          (estado),
  CONSTRAINT fk_prestamo_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_prestamo_libro
    FOREIGN KEY (libro_id)   REFERENCES libros(id)   ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO usuarios (nombre, email, password, rol) VALUES
  ('Administrador', 'admin@bookflow.com',
   '$2a$10$gO57VB0eh4WnBgxIzkUjU.5ZdCrMosA97fwdWWOrHZVL1fC8MyuWO',
   'admin'),
  ('María García', 'maria@bookflow.com',
   '$2a$10$NI/EkPR6KRkXbu5/EGPhReRY6I8ofRSoWke9Gdfol/y8g77pXdBDu',
   'usuario'),
  ('Carlos López', 'carlos@bookflow.com',
   '$2a$10$NI/EkPR6KRkXbu5/EGPhReRY6I8ofRSoWke9Gdfol/y8g77pXdBDu',
   'usuario');

INSERT INTO libros (titulo, autor, isbn, editorial, ano_publicacion, categoria, descripcion, portada_url, cantidad_total, cantidad_disponible) VALUES
  ('El Quijote',
   'Miguel de Cervantes', '978-84-376-0494-7', 'Cátedra', 1605, 'Clásicos',
   'La obra cumbre de la literatura española.',
   'https://books.google.com/books/content?id=Ux8TAAAAQBAJ&printsec=frontcover&img=1&zoom=1',
   3, 3),

  ('Cien años de soledad',
   'Gabriel García Márquez', '978-84-397-0498-5', 'Sudamericana', 1967, 'Clásicos',
   'La historia de la familia Buendía en Macondo.',
   'https://books.google.com/books/content?id=vH0NAQAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('1984',
   'George Orwell', '978-84-233-0799-5', 'Destino', 1949, 'Ciencia Ficción',
   'Una distopía sobre el totalitarismo y la vigilancia.',
   'https://books.google.com/books/content?id=kotPYEqx7kMC&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Un mundo feliz',
   'Aldous Huxley', '978-84-233-1668-3', 'Destino', 1932, 'Ciencia Ficción',
   'Una sociedad futura controlada por el placer y el condicionamiento.',
   'https://books.google.com/books/content?id=ydQuEAAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Dune',
   'Frank Herbert', '978-84-480-0817-4', 'Acervo', 1965, 'Ciencia Ficción',
   'La épica historia del planeta desértico Arrakis.',
   'https://books.google.com/books/content?id=B1hSG45JCX4C&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('El señor de los anillos',
   'J.R.R. Tolkien', '978-84-450-7179-7', 'Minotauro', 1954, 'Fantasía',
   'La gran aventura de la Tierra Media.',
   'https://books.google.com/books/content?id=yl4dILkcqm4C&printsec=frontcover&img=1&zoom=1',
   3, 3),

  ('Harry Potter y la piedra filosofal',
   'J.K. Rowling', '978-84-9838-000-1', 'Salamandra', 1997, 'Fantasía',
   'El inicio de las aventuras del joven mago Harry Potter.',
   'https://books.google.com/books/content?id=wrOQLV6xB-wC&printsec=frontcover&img=1&zoom=1',
   3, 3),

  ('El nombre del viento',
   'Patrick Rothfuss', '978-84-9800-235-5', 'Plaza & Janés', 2007, 'Fantasía',
   'La historia de Kvothe, el mago más famoso de su época.',
   'https://books.google.com/books/content?id=oSGnkgAACAAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Crimen y castigo',
   'Fiódor Dostoyevski', '978-84-376-0271-4', 'Cátedra', 1866, 'Clásicos',
   'El dilema moral de un estudiante que comete un asesinato.',
   'https://books.google.com/books/content?id=P9IQAAAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Orgullo y prejuicio',
   'Jane Austen', '978-84-376-0227-1', 'Cátedra', 1813, 'Clásicos',
   'Una historia de amor en la Inglaterra del siglo XIX.',
   'https://books.google.com/books/content?id=ingDAAAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('El gran Gatsby',
   'F. Scott Fitzgerald', '978-84-233-3438-0', 'Destino', 1925, 'Clásicos',
   'La decadencia del sueño americano en los años 20.',
   'https://books.google.com/books/content?id=iXn5U2IzVH0C&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Matar a un ruiseñor',
   'Harper Lee', '978-84-233-3827-2', 'Destino', 1960, 'Clásicos',
   'La lucha por la justicia racial en el sur de Estados Unidos.',
   'https://books.google.com/books/content?id=PGR2AwAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('El código Da Vinci',
   'Dan Brown', '978-84-08-04753-9', 'Planeta', 2003, 'Thriller',
   'Un misterio que mezcla arte, religión y conspiraciones.',
   'https://books.google.com/books/content?id=yI2NDQAAQBAJ&printsec=frontcover&img=1&zoom=1',
   3, 3),

  ('Millennium: Los hombres que no amaban a las mujeres',
   'Stieg Larsson', '978-84-233-3875-3', 'Destino', 2005, 'Thriller',
   'Una investigación sobre una desaparición familiar en Suecia.',
   'https://books.google.com/books/content?id=XcFbswEACAAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('El silencio de los corderos',
   'Thomas Harris', '978-84-233-2498-5', 'Destino', 1988, 'Thriller',
   'El agente Clarice Starling busca a un asesino en serie.',
   'https://books.google.com/books/content?id=0J9NAAAACAAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Clean Code',
   'Robert C. Martin', '978-0-13-235088-4', 'Prentice Hall', 2008, 'Programación',
   'Guía para escribir código limpio y mantenible.',
   'https://books.google.com/books/content?id=_i6bDeoCQzsC&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('JavaScript: The Good Parts',
   'Douglas Crockford', '978-0-596-51774-8', 'O\'Reilly', 2008, 'Programación',
   'Las mejores partes del lenguaje JavaScript.',
   'https://books.google.com/books/content?id=PXa2bby0oQ0C&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Node.js en Acción',
   'Mike Cantelon', '978-1-61729-257-5', 'Manning', 2017, 'Programación',
   'Desarrollo de aplicaciones web con Node.js.',
   'https://books.google.com/books/content?id=3yFMDwAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('El programador pragmático',
   'Andrew Hunt', '978-84-9835-267-4', 'Anaya', 1999, 'Programación',
   'Consejos prácticos para mejorar como desarrollador.',
   'https://books.google.com/books/content?id=5wBQEp6ruIAC&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Diseño Web con CSS',
   'Eric Meyer', '978-0-596-52736-5', 'O\'Reilly', 2010, 'Diseño Web',
   'Referencia completa de CSS para diseño web profesional.',
   'https://books.google.com/books/content?id=xhVUAAAAMAAJ&printsec=frontcover&img=1&zoom=1',
   1, 1),

  ('HTML5 y CSS3',
   'Brian Hogan', '978-1-93435-668-5', 'Pragmatic', 2011, 'Diseño Web',
   'Desarrollo web moderno con HTML5 y CSS3.',
   'https://books.google.com/books/content?id=Ht6cMQEACAAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Bases de Datos Relacionales',
   'Ramez Elmasri', '978-0-13-468859-9', 'Pearson', 2015, 'Bases de Datos',
   'Fundamentos de sistemas de bases de datos relacionales.',
   'https://books.google.com/books/content?id=PcmjBQAAQBAJ&printsec=frontcover&img=1&zoom=1',
   1, 1),

  ('El arte de la guerra',
   'Sun Tzu', '978-84-473-5087-2', 'Edaf', 500, 'Historia',
   'Tratado militar de la antigua China.',
   'https://books.google.com/books/content?id=o8GqT8MFBuYC&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Sapiens',
   'Yuval Noah Harari', '978-84-9992-395-7', 'Debate', 2011, 'Historia',
   'Una breve historia de la humanidad.',
   'https://books.google.com/books/content?id=1EiJAwAAQBAJ&printsec=frontcover&img=1&zoom=1',
   3, 3),

  ('Breve historia del tiempo',
   'Stephen Hawking', '978-84-08-17511-5', 'Planeta', 1988, 'Ciencia',
   'Los grandes misterios del universo explicados para todos.',
   'https://books.google.com/books/content?id=oZhagX6NKUEC&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('El gen egoísta',
   'Richard Dawkins', '978-84-344-8156-3', 'Salvat', 1976, 'Ciencia',
   'La evolución vista desde la perspectiva del gen.',
   'https://books.google.com/books/content?id=WkHO9HI7koEC&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Cosmos',
   'Carl Sagan', '978-84-08-04745-4', 'Planeta', 1980, 'Ciencia',
   'Un viaje por el universo y la historia de la astronomía.',
   'https://books.google.com/books/content?id=_-XHz_Ca-6AC&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('El principito',
   'Antoine de Saint-Exupéry', '978-84-261-3289-7', 'Juventud', 1943, 'Infantil',
   'Un cuento filosófico sobre la amistad y la vida.',
   'https://books.google.com/books/content?id=fGYXAAAAYAAJ&printsec=frontcover&img=1&zoom=1',
   3, 3),

  ('Matilda',
   'Roald Dahl', '978-84-204-4596-1', 'Alfaguara', 1988, 'Infantil',
   'La historia de una niña prodigio con poderes especiales.',
   'https://books.google.com/books/content?id=FBkEAAAACAAJ&printsec=frontcover&img=1&zoom=1',
   3, 3),

  ('Los juegos del hambre',
   'Suzanne Collins', '978-84-272-0001-4', 'Molino', 2008, 'Juvenil',
   'Una distopía donde jóvenes luchan por sobrevivir en televisión.',
   'https://books.google.com/books/content?id=sazytgAACAAJ&printsec=frontcover&img=1&zoom=1',
   3, 3),

  ('Divergente',
   'Veronica Roth', '978-84-272-0170-7', 'Molino', 2011, 'Juvenil',
   'Una sociedad dividida en facciones según la personalidad.',
   'https://books.google.com/books/content?id=HvwtAgAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('El diario de Ana Frank',
   'Ana Frank', '978-84-233-0375-1', 'Destino', 1947, 'Biografía',
   'El diario de una joven judía durante la Segunda Guerra Mundial.',
   'https://books.google.com/books/content?id=0XQEAAAAMBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Steve Jobs',
   'Walter Isaacson', '978-84-08-01511-8', 'Planeta', 2011, 'Biografía',
   'La vida del cofundador de Apple.',
   'https://books.google.com/books/content?id=8U2oAAAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Elon Musk',
   'Walter Isaacson', '978-84-08-27401-2', 'Planeta', 2023, 'Biografía',
   'La historia del emprendedor detrás de Tesla y SpaceX.',
   'https://books.google.com/books/content?id=yp-oEAAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Padre rico, padre pobre',
   'Robert Kiyosaki', '978-84-663-2478-5', 'Debolsillo', 1997, 'Economía',
   'Lecciones sobre finanzas personales e inversión.',
   'https://books.google.com/books/content?id=ovGwDwAAQBAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('El inversor inteligente',
   'Benjamin Graham', '978-84-234-2804-9', 'Deusto', 1949, 'Economía',
   'La biblia del inversor en valor.',
   'https://books.google.com/books/content?id=gqBHAAAAYAAJ&printsec=frontcover&img=1&zoom=1',
   1, 1),

  ('Hábitos atómicos',
   'James Clear', '978-84-16883-69-8', 'Diana', 2018, 'Autoayuda',
   'Cómo construir buenos hábitos y eliminar los malos.',
   'https://books.google.com/books/content?id=XfFvDwAAQBAJ&printsec=frontcover&img=1&zoom=1',
   3, 3),

  ('El poder del ahora',
   'Eckhart Tolle', '978-84-253-3544-5', 'Grijalbo', 1997, 'Autoayuda',
   'Una guía para la iluminación espiritual.',
   'https://books.google.com/books/content?id=254NAQAAMAAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('La Odisea',
   'Homero', '978-84-376-0273-8', 'Cátedra', 800, 'Clásicos',
   'El viaje de Ulises de regreso a Ítaca tras la guerra de Troya.',
   'https://books.google.com/books/content?id=YZ9HAAAAYAAJ&printsec=frontcover&img=1&zoom=1',
   2, 2),

  ('Frankenstein',
   'Mary Shelley', '978-84-376-0248-6', 'Cátedra', 1818, 'Terror',
   'El científico que crea vida y las consecuencias de jugar a ser Dios.',
   'https://books.google.com/books/content?id=0FZVAAAAMAAJ&printsec=frontcover&img=1&zoom=1',
   2, 2);

INSERT INTO prestamos (usuario_id, libro_id, fecha_devolucion_esperada, estado) VALUES
  (2, 2, DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'activo'),
  (3, 3, DATE_ADD(CURDATE(), INTERVAL 7  DAY), 'activo'),
  (2, 1, DATE_SUB(CURDATE(), INTERVAL 5  DAY), 'vencido');

UPDATE libros SET cantidad_disponible = cantidad_disponible - 1 WHERE id IN (1, 2, 3);
