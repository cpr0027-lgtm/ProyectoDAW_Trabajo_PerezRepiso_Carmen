const express = require('express');
const router = express.Router();
const libroController = require('../controllers/libroController');
const { verifyToken, requireAdmin } = require('../middleware/auth');
const { requireFields, validId } = require('../middleware/validate');

router.get('/',           verifyToken, libroController.getAllLibros);
router.get('/categorias', verifyToken, libroController.getCategorias);
router.get('/:id',        verifyToken, validId(), libroController.getLibroById);

router.post(
  '/',
  verifyToken, requireAdmin,
  requireFields(['titulo', 'autor']),
  libroController.crearLibro,
);

router.put(
  '/:id',
  verifyToken, requireAdmin,
  validId(),
  requireFields(['titulo', 'autor']),
  libroController.actualizarLibro,
);

router.delete(
  '/:id',
  verifyToken, requireAdmin,
  validId(),
  libroController.eliminarLibro,
);

module.exports = router;
