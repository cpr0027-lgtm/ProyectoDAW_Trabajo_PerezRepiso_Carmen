const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/usuarioController');
const { verifyToken, requireAdmin } = require('../middleware/auth');
const { validId } = require('../middleware/validate');

router.post('/login',    usuarioController.login);
router.post('/registro', usuarioController.registro);

router.get('/',          verifyToken, requireAdmin, usuarioController.getUsuarios);
router.put('/:id/rol',   verifyToken, requireAdmin, validId(), usuarioController.cambiarRol);
router.delete('/:id',    verifyToken, requireAdmin, validId(), usuarioController.desactivarUsuario);

module.exports = router;
