const express = require('express');
const router = express.Router();
const prestamoController = require('../controllers/prestamoController');
const { verifyToken, requireAdmin } = require('../middleware/auth');
const { requireFields, validId } = require('../middleware/validate');

router.get('/estadisticas', verifyToken, requireAdmin, prestamoController.getEstadisticas);
router.get('/mios',         verifyToken, prestamoController.getMisPrestamos);
router.get('/',             verifyToken, requireAdmin, prestamoController.getPrestamos);

router.post(
  '/',
  verifyToken, requireAdmin,
  requireFields(['usuario_id', 'libro_id']),
  prestamoController.crearPrestamo,
);

router.put('/:id/devolver', verifyToken, requireAdmin, validId(), prestamoController.devolverLibro);

module.exports = router;
