'use strict';

document.addEventListener('DOMContentLoaded', () => {
  if (!checkAuth()) return;
  renderUserName();

  if (isAdmin()) {
    cargarEstadisticasAdmin();
  } else {
    mostrarDashboardUsuario();
  }
});

async function cargarEstadisticasAdmin() {
  try {
    const res = await fetch(`${API_URL}/prestamos/estadisticas`, {
      headers: authHeaders(),
    });

    if (!res.ok) throw new Error('No se pudieron cargar las estadísticas.');

    const data = await res.json();

    setStatValue('stat-libros',      data.libros?.total_libros    ?? '—');
    setStatValue('stat-disponibles', data.libros?.disponibles      ?? '—');
    setStatValue('stat-prestamos',   data.prestamos?.activos       ?? '—');
    setStatValue('stat-vencidos',    data.prestamos?.vencidos      ?? '—');
    setStatValue('stat-usuarios',    data.usuarios?.total_usuarios ?? '—');
  } catch (error) {
    console.error('[main.js] cargarEstadisticasAdmin:', error);
  }
}

function mostrarDashboardUsuario() {
  const seccionStats = document.getElementById('seccion-stats');
  const seccionAdmin = document.getElementById('seccion-acciones-admin');
  const seccionUsuario = document.getElementById('seccion-acciones-usuario');

  if (seccionStats)   seccionStats.classList.add('d-none');
  if (seccionAdmin)   seccionAdmin.classList.add('d-none');
  if (seccionUsuario) seccionUsuario.classList.remove('d-none');
}

function setStatValue(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}
