'use strict';

let todosLosLibros = [];
let libroEditandoId = null;

document.addEventListener('DOMContentLoaded', () => {
  if (!checkAuth()) return;
  renderUserName();

  cargarLibros();
  cargarCategorias();

  document.getElementById('buscarLibro').addEventListener('input', filtrarLibros);
  document.getElementById('filtroCategoria').addEventListener('change', filtrarLibros);

  if (isAdmin()) {
    document.querySelectorAll('.admin-only').forEach(el => el.classList.remove('d-none'));
    document.getElementById('page-title').textContent = '📚 Gestión de Libros';
    document.getElementById('seccion-formulario').classList.remove('d-none');
    document.getElementById('formLibro').addEventListener('submit', guardarLibro);
    const btnCancelar = document.getElementById('btnCancelarEdicion');
    if (btnCancelar) btnCancelar.addEventListener('click', cancelarEdicion);
  }
});

async function cargarLibros() {
  try {
    const res = await fetch(`${API_URL}/libros`, { headers: authHeaders() });
    if (!res.ok) throw new Error('Error al cargar libros');
    todosLosLibros = await res.json();
    renderCatalogoLibros(todosLosLibros);
  } catch (error) {
    console.error('[libros.js] cargarLibros:', error);
    showToast('No se pudieron cargar los libros.', 'danger');
  }
}

async function cargarCategorias() {
  try {
    const res = await fetch(`${API_URL}/libros/categorias`, { headers: authHeaders() });
    if (!res.ok) return;
    const categorias = await res.json();
    const select = document.getElementById('filtroCategoria');
    categorias.forEach((cat) => {
      const opt = document.createElement('option');
      opt.value = cat;
      opt.textContent = cat;
      select.appendChild(opt);
    });
  } catch (error) {
    console.error('[libros.js] cargarCategorias:', error);
  }
}

async function guardarLibro(e) {
  e.preventDefault();

  const libro = {
    titulo:          document.getElementById('titulo').value.trim(),
    autor:           document.getElementById('autor').value.trim(),
    isbn:            document.getElementById('isbn').value.trim(),
    editorial:       document.getElementById('editorial').value.trim(),
    ano_publicacion: document.getElementById('ano_publicacion').value || null,
    categoria:       document.getElementById('categoria').value.trim(),
    descripcion:     document.getElementById('descripcion').value.trim(),
    cantidad_total:  parseInt(document.getElementById('cantidad').value, 10) || 1,
  };

  const isEditing = libroEditandoId !== null;
  const url    = isEditing ? `${API_URL}/libros/${libroEditandoId}` : `${API_URL}/libros`;
  const method = isEditing ? 'PUT' : 'POST';

  try {
    const res = await fetch(url, { method, headers: authHeaders(), body: JSON.stringify(libro) });
    const data = await res.json();

    if (res.ok) {
      showToast(isEditing ? 'Libro actualizado correctamente.' : 'Libro añadido correctamente.');
      document.getElementById('formLibro').reset();
      cancelarEdicion();
      cargarLibros();
    } else {
      showToast(data.error || data.mensaje || 'Error al guardar el libro.', 'danger');
    }
  } catch (error) {
    showToast('Error de conexión con el servidor.', 'danger');
  }
}

async function eliminarLibro(id) {
  if (!confirm('¿Seguro que quieres eliminar este libro?')) return;

  try {
    const res = await fetch(`${API_URL}/libros/${id}`, { method: 'DELETE', headers: authHeaders() });
    if (res.ok) {
      showToast('Libro eliminado correctamente.');
      cargarLibros();
    }
  } catch (error) {
    showToast('Error de conexión.', 'danger');
  }
}

function editarLibro(id) {
  const libro = todosLosLibros.find((l) => l.id === id);
  if (!libro) return;

  libroEditandoId = id;

  document.getElementById('titulo').value          = libro.titulo          || '';
  document.getElementById('autor').value           = libro.autor           || '';
  document.getElementById('isbn').value            = libro.isbn            || '';
  document.getElementById('editorial').value       = libro.editorial       || '';
  document.getElementById('ano_publicacion').value = libro.ano_publicacion || '';
  document.getElementById('categoria').value       = libro.categoria       || '';
  document.getElementById('descripcion').value     = libro.descripcion     || '';
  document.getElementById('cantidad').value        = libro.cantidad_total  || 1;

  document.getElementById('formTitulo').textContent = 'Editar Libro';
  document.getElementById('btnGuardar').textContent = 'Actualizar Libro';
  document.getElementById('btnCancelarEdicion').classList.remove('d-none');
  document.getElementById('seccion-formulario').scrollIntoView({ behavior: 'smooth' });
}

function cancelarEdicion() {
  libroEditandoId = null;
  document.getElementById('formLibro').reset();
  document.getElementById('formTitulo').textContent = 'Añadir Nuevo Libro';
  document.getElementById('btnGuardar').textContent = 'Añadir Libro';
  const btnCancelar = document.getElementById('btnCancelarEdicion');
  if (btnCancelar) btnCancelar.classList.add('d-none');
}

function filtrarLibros() {
  const texto     = document.getElementById('buscarLibro').value.toLowerCase();
  const categoria = document.getElementById('filtroCategoria').value;

  const filtrados = todosLosLibros.filter((l) => {
    const coincideTexto = !texto
      || l.titulo.toLowerCase().includes(texto)
      || l.autor.toLowerCase().includes(texto);
    const coincideCategoria = !categoria || l.categoria === categoria;
    return coincideTexto && coincideCategoria;
  });

  renderCatalogoLibros(filtrados);
}

function portadaUrl(libro) {
  if (!libro?.titulo) return 'assets/Portadas/placeholder.png';

  const titulo = libro.titulo.toLowerCase().trim();

  const map = {
    "1984": "1984",
    "cien años de soledad": "cien-anos-soledad",
    "el quijote": "quijote",
    "el señor de los anillos": "senor-anillos",
    "harry potter y la piedra filosofal": "harry-potter",
    "el nombre del viento": "nombre-viento",
    "crimen y castigo": "crimen-castigo",
    "orgullo y prejuicio": "orgullo-prejuicio",
    "el gran gatsby": "gran-gatsby",
    "matar a un ruiseñor": "matar-ruisenor",
    "el código da vinci": "codigo-davinci",
    "los juegos del hambre": "juegos-hambre",
    "padre rico, padre pobre": "padre-rico",
    "el programador pragmático": "programador-pragmatico",
    "el arte de la guerra": "arte-guerra",
    "un mundo feliz": "un-mundo-feliz",
    "steve jobs": "steve-jobs",
    "sapiens": "sapiens",
    "clean code": "clean-code",
    "el principito": "principito",
    "breve historia del tiempo": "breve-historia-tiempo",
    "cosmos": "cosmos",
    "dune": "dune",
    "divergente": "divergente",
    "frankenstein": "frankenstein",
    "el silencio de los corderos": "silencio-corderos",
    "matilda": "matilda",
    "el diario de ana frank": "diario-ana-frank",
    "bases de datos relacionales": "bases-de-datos",
    "diseño web con css": "css-web",
    "el gen egoísta": "gen-egoista",
    "html5 y css3": "html5-css3",
    "javascript: the good parts": "javascript-good-parts",
    "millennium: los hombres que no amaban a las mujeres": "millennium",
    "node.js en acción": "nodejs-accion",
    "el inversor inteligente": "inversor-inteligente",
    "el poder del ahora": "poder-ahora",
    "hábitos atómicos": "habitos-atomicos",
    "la odisea": "odisea",                    // ← Añadido
    "la odisea de homero": "odisea"
  };

  let nombre = map[titulo];

  if (!nombre) {
    nombre = titulo.replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, "-");
  }

  return `assets/Portadas/${nombre}.png`;
}

function renderCatalogoLibros(libros) {
  const contenedor = document.getElementById('catalogo-grid');
  contenedor.innerHTML = '';

  if (libros.length === 0) {
    contenedor.innerHTML = `
      <div class="col-12">
        <div class="empty-state">
          <div class="empty-icon">📚</div>
          <p>No se encontraron libros.</p>
        </div>
      </div>`;
    return;
  }

  const admin = isAdmin();

  libros.forEach((libro) => {
    const urlPortada = portadaUrl(libro);

    const imgHtml = urlPortada 
      ? `<img src="${urlPortada}" 
              alt="Portada de ${escapeHtml(libro.titulo)}"
              class="libro-portada"
              onerror="this.onerror=null; this.src='assets/Portadas/placeholder.png';">`
      : `<div class="libro-portada-placeholder">📚</div>`;

    const badgeDisp = libro.cantidad_disponible > 0
      ? `<span class="badge bg-success">${libro.cantidad_disponible} disp.</span>`
      : `<span class="badge bg-danger">Sin stock</span>`;

    const botonesAdmin = admin ? `
      <div class="d-flex gap-1 mt-2">
        <button class="btn btn-sm btn-outline-primary flex-fill"
                onclick="editarLibro(${libro.id})">✏️ Editar</button>
        <button class="btn btn-sm btn-outline-danger flex-fill"
                onclick="eliminarLibro(${libro.id})">🗑️ Eliminar</button>
      </div>` : '';

    const col = document.createElement('div');
    col.className = 'col-6 col-sm-4 col-md-3 col-lg-2';
    col.innerHTML = `
      <div class="libro-card card h-100">
        <div class="libro-portada-wrapper">
          ${imgHtml}
        </div>
        <div class="card-body p-2 d-flex flex-column">
          <h3 class="libro-titulo">${escapeHtml(libro.titulo)}</h3>
          <p class="libro-autor">${escapeHtml(libro.autor)}</p>
          <div class="mt-auto">
            <span class="libro-categoria">${escapeHtml(libro.categoria || '—')}</span>
            <div class="mt-1">${badgeDisp}</div>
            ${botonesAdmin}
          </div>
        </div>
      </div>`;
    contenedor.appendChild(col);
  });
}

function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
