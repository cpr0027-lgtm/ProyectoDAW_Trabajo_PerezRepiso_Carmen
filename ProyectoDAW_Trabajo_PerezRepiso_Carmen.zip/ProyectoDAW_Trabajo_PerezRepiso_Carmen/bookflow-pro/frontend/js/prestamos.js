'use strict';

document.addEventListener('DOMContentLoaded', () => {
  if (!checkAuth()) return;
  renderUserName();

  if (isAdmin()) {
    document.getElementById('seccion-nuevo-prestamo').classList.remove('d-none');
    cargarOpcionesFormulario();
    document.getElementById('formPrestamo').addEventListener('submit', crearPrestamo);
  }

  cargarPrestamos();
  document.getElementById('filtroEstado').addEventListener('change', () => cargarPrestamos());
});

async function cargarPrestamos() {
  const estado = document.getElementById('filtroEstado').value;
  let url;

  if (isAdmin()) {
    url = estado ? `${API_URL}/prestamos?estado=${estado}` : `${API_URL}/prestamos`;
  } else {
    const usuario = getUsuario();
    url = estado
      ? `${API_URL}/prestamos/mios?estado=${estado}`
      : `${API_URL}/prestamos/mios`;
  }

  try {
    const res = await fetch(url, { headers: authHeaders() });
    if (!res.ok) throw new Error('Error al cargar préstamos');

    const prestamos = await res.json();
    renderTablaPrestamos(prestamos);
  } catch (error) {
    console.error('[prestamos.js] cargarPrestamos:', error);
    showToast('No se pudieron cargar los préstamos.', 'danger');
  }
}

async function cargarOpcionesFormulario() {
  try {
    const resLibros = await fetch(`${API_URL}/libros`, { headers: authHeaders() });
    const libros = await resLibros.json();

    const selectLibro = document.getElementById('prestamoLibro');
    libros
      .filter((l) => l.cantidad_disponible > 0)
      .forEach((l) => {
        const opt = document.createElement('option');
        opt.value = l.id;
        opt.textContent = `${l.titulo} — ${l.autor} (${l.cantidad_disponible} disp.)`;
        selectLibro.appendChild(opt);
      });

    const resUsuarios = await fetch(`${API_URL}/usuarios`, { headers: authHeaders() });
    const usuarios = await resUsuarios.json();

    const selectUsuario = document.getElementById('prestamoUsuario');
    usuarios.forEach((u) => {
      const opt = document.createElement('option');
      opt.value = u.id;
      opt.textContent = `${u.nombre} (${u.email})`;
      selectUsuario.appendChild(opt);
    });

    const defaultDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000)
      .toISOString().split('T')[0];
    document.getElementById('prestamoFecha').value = defaultDate;
  } catch (error) {
    console.error('[prestamos.js] cargarOpcionesFormulario:', error);
  }
}

async function crearPrestamo(e) {
  e.preventDefault();

  const prestamo = {
    libro_id:                  parseInt(document.getElementById('prestamoLibro').value, 10),
    usuario_id:                parseInt(document.getElementById('prestamoUsuario').value, 10),
    fecha_devolucion_esperada: document.getElementById('prestamoFecha').value,
    notas:                     document.getElementById('prestamoNotas').value.trim() || null,
  };

  try {
    const res = await fetch(`${API_URL}/prestamos`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(prestamo),
    });

    const data = await res.json();

    if (res.ok) {
      showToast('Préstamo registrado correctamente.');
      document.getElementById('formPrestamo').reset();
      document.getElementById('prestamoLibro').innerHTML = '<option value="">-- Selecciona un libro --</option>';
      document.getElementById('prestamoUsuario').innerHTML = '<option value="">-- Selecciona un usuario --</option>';
      cargarOpcionesFormulario();
      cargarPrestamos();
    } else {
      showToast(data.error || data.mensaje || 'Error al crear el préstamo.', 'danger');
    }
  } catch (error) {
    showToast('Error de conexión con el servidor.', 'danger');
  }
}

async function devolverLibro(id) {
  if (!confirm('¿Confirmar devolución de este libro?')) return;

  try {
    const res = await fetch(`${API_URL}/prestamos/${id}/devolver`, {
      method: 'PUT',
      headers: authHeaders(),
    });

    const data = await res.json();

    if (res.ok) {
      showToast('Libro devuelto correctamente.');
      cargarPrestamos();
    } else {
      showToast(data.error || 'No se pudo registrar la devolución.', 'danger');
    }
  } catch (error) {
    showToast('Error de conexión.', 'danger');
  }
}

function renderTablaPrestamos(prestamos) {
  const tbody = document.querySelector('#tablaPrestamos tbody');
  tbody.innerHTML = '';

  const admin = isAdmin();

  if (prestamos.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="${admin ? 6 : 4}" class="text-center text-muted py-4">
          <div class="empty-state">
            <div class="empty-icon">🔄</div>
            <p>No hay préstamos que mostrar.</p>
          </div>
        </td>
      </tr>`;
    return;
  }

  prestamos.forEach((p) => {
    const hoy = new Date();
    const fechaEsperada = new Date(p.fecha_devolucion_esperada);
    const vencido = p.estado === 'activo' && fechaEsperada < hoy;

    const estadoBadge = {
      activo:   vencido ? '<span class="badge bg-danger">Vencido</span>' : '<span class="badge bg-warning text-dark">Activo</span>',
      devuelto: '<span class="badge bg-success">Devuelto</span>',
      vencido:  '<span class="badge bg-danger">Vencido</span>',
    }[p.estado] || `<span class="badge bg-secondary">${p.estado}</span>`;

    const colUsuario = admin ? `<td>${escapeHtml(p.usuario_nombre)}</td>` : '';

    const colAccion = admin && p.estado === 'activo'
      ? `<td><button class="btn btn-sm btn-success"
                     onclick="devolverLibro(${p.id})"
                     aria-label="Devolver ${escapeHtml(p.libro_titulo)}">
           Devolver
         </button></td>`
      : admin ? '<td>—</td>' : '';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${escapeHtml(p.libro_titulo)}</strong></td>
      ${colUsuario}
      <td>${formatDate(p.fecha_prestamo)}</td>
      <td>${formatDate(p.fecha_devolucion_esperada)}</td>
      <td>${estadoBadge}</td>
      ${colAccion}`;
    tbody.appendChild(tr);
  });
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('es-ES', {
    day: '2-digit', month: '2-digit', year: 'numeric',
  });
}

function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
