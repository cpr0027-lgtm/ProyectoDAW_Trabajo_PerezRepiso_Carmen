'use strict';

document.addEventListener('DOMContentLoaded', () => {
  if (!checkAuth()) return;
  renderUserName();
  cargarUsuarios();
});

async function cargarUsuarios() {
  try {
    const res = await fetch(`${API_URL}/usuarios`, { headers: authHeaders() });
    if (!res.ok) throw new Error('Error al cargar usuarios');

    const usuarios = await res.json();
    renderTablaUsuarios(usuarios);

    const contador = document.getElementById('contadorUsuarios');
    if (contador) contador.textContent = `${usuarios.length} usuarios`;
  } catch (error) {
    console.error('[usuarios.js] cargarUsuarios:', error);
    showToast('No se pudieron cargar los usuarios.', 'danger');
  }
}

async function cambiarRol(id, rolActual) {
  const nuevoRol = rolActual === 'admin' ? 'usuario' : 'admin';
  if (!confirm(`¿Cambiar el rol a "${nuevoRol}"?`)) return;

  try {
    const res = await fetch(`${API_URL}/usuarios/${id}/rol`, {
      method: 'PUT',
      headers: authHeaders(),
      body: JSON.stringify({ rol: nuevoRol }),
    });

    const data = await res.json();

    if (res.ok) {
      showToast('Rol actualizado correctamente.');
      cargarUsuarios();
    } else {
      showToast(data.mensaje || 'Error al cambiar el rol.', 'danger');
    }
  } catch (error) {
    showToast('Error de conexión.', 'danger');
  }
}

async function desactivarUsuario(id) {
  if (!confirm('¿Desactivar este usuario? No podrá iniciar sesión.')) return;

  try {
    const res = await fetch(`${API_URL}/usuarios/${id}`, {
      method: 'DELETE',
      headers: authHeaders(),
    });

    const data = await res.json();

    if (res.ok) {
      showToast('Usuario desactivado correctamente.');
      cargarUsuarios();
    } else {
      showToast(data.mensaje || 'No se pudo desactivar el usuario.', 'danger');
    }
  } catch (error) {
    showToast('Error de conexión.', 'danger');
  }
}

function renderTablaUsuarios(usuarios) {
  const tbody = document.querySelector('#tablaUsuarios tbody');
  tbody.innerHTML = '';

  if (usuarios.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center text-muted py-4">
          <div class="empty-state">
            <div class="empty-icon">👥</div>
            <p>No hay usuarios registrados.</p>
          </div>
        </td>
      </tr>`;
    return;
  }

  const miId = JSON.parse(localStorage.getItem('usuario') || '{}').id;

  usuarios.forEach((u) => {
    const rolBadge = u.rol === 'admin'
      ? '<span class="badge bg-primary">Admin</span>'
      : '<span class="badge bg-secondary">Usuario</span>';

    const estadoBadge = u.activo
      ? '<span class="badge bg-success">Activo</span>'
      : '<span class="badge bg-danger">Inactivo</span>';

    const esMiCuenta = u.id === miId;

    const acciones = esMiCuenta
      ? '<span class="text-muted small">Tu cuenta</span>'
      : `
        <button class="btn btn-sm btn-outline-primary me-1"
                onclick="cambiarRol(${u.id}, '${u.rol}')"
                aria-label="Cambiar rol de ${escapeHtml(u.nombre)}">
          Cambiar rol
        </button>
        ${u.activo ? `
        <button class="btn btn-sm btn-outline-danger"
                onclick="desactivarUsuario(${u.id})"
                aria-label="Desactivar ${escapeHtml(u.nombre)}">
          Desactivar
        </button>` : ''}`;

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${escapeHtml(u.nombre)}</strong></td>
      <td>${escapeHtml(u.email)}</td>
      <td>${rolBadge}</td>
      <td>${estadoBadge}</td>
      <td>${formatDate(u.fecha_registro)}</td>
      <td>${acciones}</td>`;
    tbody.appendChild(tr);
  });
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('es-ES', {
    day: '2-digit', month: '2-digit', year: 'numeric',
  });
}

function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
